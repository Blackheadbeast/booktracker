package com.grayseal.bookshelf.data

data class BottomNavItem(
    val name: String,
    val route: String,
    val icon: Int,
)
