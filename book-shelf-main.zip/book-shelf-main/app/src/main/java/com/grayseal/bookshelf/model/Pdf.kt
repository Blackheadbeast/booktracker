package com.grayseal.bookshelf.model

data class Pdf(
    val acsTokenLink: String?,
    val isAvailable: Boolean?
)