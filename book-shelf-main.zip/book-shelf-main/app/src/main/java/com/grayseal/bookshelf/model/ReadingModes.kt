package com.grayseal.bookshelf.model

data class ReadingModes(
    val image: Boolean?,
    val text: Boolean?
)